const tblAngler = [
      {
         ID: 1,
         Angler: "Willie"
      }
   ]
  
   export default tblAngler;