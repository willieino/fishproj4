const tblLineColor = [
      {
            ID: 1,
            LineColor: "Clear"
      },
      {
            ID: 2,
            LineColor: "Green"
      }
]

export default tblLineColor;