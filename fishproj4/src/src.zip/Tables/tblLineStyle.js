const tblLineStyle = [
      {
            ID: 1,
            LineStyle: "Braid"
      }
]

export default tblLineStyle;