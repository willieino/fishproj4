const tblHookType = [
      {
            ID: 1,
            HookType: "Circle"
      }
]

export default tblHookType;
