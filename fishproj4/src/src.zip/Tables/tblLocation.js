const tblLocation = [
      {
            ID: 1,
            Place: "Lake Murray"
      }
]

export default tblLocation;