const TripTbl = [
    {
        ID: 1,
        Trip: "Murray1",
        StartDate: "2009-01-10T00:00:00",
        Duration: 1,
        Place: "Lake Murray",
        Photos: "F:\\D_Drive\\FishProject\\images\\bass-1024.jpg",
        Notes: "blah",
        Anglers: "Willie",
        GPS1: "N23.234",
        GPS2: "W34.567",
        ImgCaption: "guess the fish size and win!"
    }
]

export default TripTbl;