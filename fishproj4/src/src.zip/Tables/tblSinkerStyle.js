const tblSinkerStyle = [
    {
        ID: 1,
        SinkerStyle: "split shot"
    }
]

export default tblSinkerStyle;