const tblSky = [
    {
        ID: 2,
        skyCondition: "Cloudy"
    }
]

export default tblSky;