const tblLunarPhase = [
      {
            ID: 2,
            LunarPhase: "Full"
      }
]

export default tblLunarPhase;