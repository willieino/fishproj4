const tblBait = [
         {
            ID: 1,
            Bait: "Senko"
         },
         {
            ID: 2,
            Bait: "Shiner"
         }
      ]
    
      export default tblBait;