const tblOutcome = [
    {
        ID: 1,
        Outcome: "Released"
    },
    {
        ID: 2,
        Outcome: "Kept"
    }
]

export default tblOutcome;