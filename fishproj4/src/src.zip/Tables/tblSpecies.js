const tblSpecies = [
      {
            ID: 2,
            Species: "LMB"
      },
      {
            ID: 3,
            Species: "Catfish"
      },
      {
            ID: 4,
            Species: "Carp"
      },
      {
            ID: 5,
            Species: "Bluegill"
      },
      {
            ID: 6,
            Species: "Red Eye"
      }
]

export default tblSpecies;