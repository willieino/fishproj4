const tblReels = [
    {
        ID: 2,
        Reel: "Shimano"
    },
    {
        ID: 3,
        Reel: "Quantuum"
    }
]
export default tblReels;