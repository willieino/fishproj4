const tblRods = [
    {
        ID: 2,
        Rod: "Shimano"
    },
    {
        ID: 3,
        Rod: "Quantuum"
    }
]

export default tblRods;