const tblBaitColor = [
      {
            ID: 1,
            BaitColor: "Pumpkin"
      },
      {
            ID: 2,
            BaitColor: "Green"
      }
]

export default tblBaitColor;
