const tblFishingSpot = [
      {
            ID: 2,
            FishingSpot: "Under the tree"
      },
      {
            ID: 3,
            FishingSpot: "By the drain"
      }
]

export default tblFishingSpot;