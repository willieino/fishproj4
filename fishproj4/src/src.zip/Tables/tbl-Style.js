const tblStyle = [
         {
            ID: 1,
            Style: "Carolina"
         },
         {
            ID: 2,
            Style: "Texas"
         },
         {
            ID: 3,
            Style: "kentucky rig"
         },
         {
            ID: 4,
            Style: "Drop Shot"
         },
         {
           ID: 5,
            Style: "Spy Bait"
         },
         {
            ID: 6,
            Style: "Fly Line"
         }
      ]
  
   export default tblStyle
