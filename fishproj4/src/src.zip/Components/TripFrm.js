import React, { Component } from 'react';
import tripTbl from "../Tables/tripTbl" 
import '../App.css';

class TripFrm extends Component {
  constructor (props) {
    super(props);

    this.state = {  
      trip: "",
      startDate: "",
      duration: 0,
      place: "",
      photos: "",
      notes: "",
      anglers: "",
      gps1: "",
      gps2: "",
      imgCaption: "",
      viewTrip: true,
      enterTrip: false
     }

  }
 
  componentDidMount() {
console.log("in the tripfrm component did mount")
console.log(this.state)
  }

  

 

  render() {
    
    return (
        <form className="trip-form" onSubmit={this.props.handleSubmit}>
        <div className="trip-container"><div className="trip-header">Enter your trip data. Press Save when finished.</div>
        <div className="input-container"><div className="trip-text">Trip Name: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler} name="Trip" />
        <div className="trip-text">Start Date: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="StartDate" />
        <div className="trip-text">Duration: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="Duration" />
        <div className="trip-text">Place: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="Place" />
        <div className="trip-text">Photos: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="Photos" />
        <div className="trip-text">Notes: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="Notes" />
        <div className="trip-text">Anglers: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="Anglers" />
        <div className="trip-text">GPS1: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="Gps1" />
        <div className="trip-text">GPS2: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="Gps2" />
        <div className="trip-text">Image Caption: </div>
        <input type="text" className="trip" value={this.props.value} onChange={this.props.changeHandler}  name="ImgCaption" />
        </div>
        <div className="button-container"> 
         <button type="submit" className="nav-button" name="saveButton" onSubmit={this.props.handleSubmit}>Save Changes</button>
       <button className="nav-button" value="Clear Fields" name="clear" onClick={this.props.clickHandler}>Clear Fields</button> 
       <button className="nav-button" name="cancel">Cancel Changes</button>  
       </div>
        </div>
        </form>
    );
  }
}

export default TripFrm;